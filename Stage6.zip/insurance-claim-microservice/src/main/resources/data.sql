insert into insurer_detail(id, insurance_amount_limit, insurer_name, insurer_package_name , disbursement_duration) values(0, 3000, 'Bajaj Insurance', 'Gold',10);
insert into insurer_detail(id, insurance_amount_limit, insurer_name, insurer_package_name , disbursement_duration) values(1, 2000, 'LIC Insurance', 'Silver',15);
insert into insurer_detail(id, insurance_amount_limit, insurer_name, insurer_package_name , disbursement_duration) values(2, 7000, 'HDFC Insurance', 'Gold',10);
insert into insurer_detail(id, insurance_amount_limit, insurer_name, insurer_package_name , disbursement_duration) values(3, 9000, 'Star Insurance', 'Bronze',20);
insert into insurer_detail(id, insurance_amount_limit, insurer_name, insurer_package_name , disbursement_duration) values(4, 4000, 'Meddibuddy Insurance', 'Platinum',18);
