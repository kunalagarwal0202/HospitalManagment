package com.cts.iptms;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class InsuranceClaimMicroserviceApplicationTest {

	@Test
	void contextLoads() 
	{
		InsuranceClaimMicroserviceApplication.main(new String[] {});
	}

}
